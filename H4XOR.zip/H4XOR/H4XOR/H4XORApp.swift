//
//  H4XORApp.swift
//  H4XOR
//
//  Created on 23/07/25.
//

import SwiftUI

@main
struct H4XORApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
